#include<iostream>
using namespace std;
class series
{
public:
int n,a=0,b=1,sum=0,count=1;
void input()
{
cout<<"enter the limit => ";
cin>>n;
}
void show()
{
while(count!=n+1)
{
cout<<sum<<"\n";
count+=1;
a=b;
b=sum;
sum=a+b;
}}
};
int main()
{
series s1;
s1.input();
s1.show();
}
